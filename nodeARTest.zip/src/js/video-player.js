const exp = module.exports;
import {infoPanel} from './info-panel'

let init = function() {
	let video = document.querySelector('.camera-feed')

	let localMediaStream = null

	let front = false;

	navigator.mediaDevices.getUserMedia({video: { facingMode: (front ? 'user' : 'environment') }, audio: false}).then(function (stream) {
		video.src = window.URL.createObjectURL(stream)
		infoPanel.add("Camera Feed Loaded Successfully...")
	}).catch(handleError)

}

function handleError(evt) {
	let video = document.querySelector('.camera-feed')
	video.parentNode.removeChild(video)

	let info = document.querySelector('.info')

	let message = `
	<p>
	  <strong>ERROR</strong>
	  <br>
	  ${evt.name}
	  <br>
	  ${evt.message}
	</p>
	`
	infoPanel.add(message)
	infoPanel.toggle(true);
}

exp.videoPlayer = {
	init: init,
}