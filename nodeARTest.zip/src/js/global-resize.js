const exp = module.exports;

exp.globalResize = function() {
	console.log('resize')
	let video = document.querySelector('.camera-feed')

	video.style.width = window.innerWidth + 'px'
	video.style.height = window.innerHeight + 'px'
}