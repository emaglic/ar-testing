const exp = module.exports;

let init = function() {
	let toggleInfo = document.querySelector('.toggle-info')
	toggleInfo.onclick = exp.infoPanel.toggle;
}

let add = function(message) {
	let info = document.querySelector('.info')
	info.innerHTML += `<br>${message}<hr>`
}

let toggle = function() {
	let info = document.querySelector('.info')
	let toggleInfoContainer = document.querySelector('.toggle-info-container')
	info.classList.toggle('visible')
	toggleInfoContainer.classList.toggle('visible')
	info.style.top = toggleInfoContainer.offsetHeight + 'px';
}

exp.infoPanel = {
	init: init,
	add: add,
	toggle: toggle
}